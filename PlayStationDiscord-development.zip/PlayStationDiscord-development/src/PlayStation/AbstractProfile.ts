export default abstract class AbstractProfile
{
    public abstract avatarUrl() : string;

    public abstract onlineId() : string;
}